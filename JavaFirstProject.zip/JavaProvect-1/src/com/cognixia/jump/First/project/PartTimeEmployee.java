package com.cognixia.jump.First.project;

public class PartTimeEmployee extends Employee{

	public PartTimeEmployee(int ID, String name, int age, String department, String occupation, int salary, String phoneNum, String email) {
		super(ID, name, age, department, occupation, salary, phoneNum, email);
	}
	
	
	@Override
	public String toString() {
		return "Part-Time " + super.toString();
	}
	
	@Override
	public String toFileFormat() {
		return "" + getID() + ",Full-Time Employee," + getName() + "," + getAge() + "," + getDept() 
		+ "," + getSalary() + "," + getPhoneNum() + "," + getEmail();
	}
}
