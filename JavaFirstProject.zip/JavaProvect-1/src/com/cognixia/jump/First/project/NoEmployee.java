package com.cognixia.jump.First.project;

public class NoEmployee extends Exception{
	
	public NoEmployee() {
		super("There are no Employees of that ID to delete");
	}

}
