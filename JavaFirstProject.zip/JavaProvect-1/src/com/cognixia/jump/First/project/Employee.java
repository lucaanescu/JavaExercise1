package com.cognixia.jump.First.project;

public class Employee {
	
	private int ID;
	private String name;
	private int age;
	private String department;
	private String occupation;
	private int salary;
	private String phoneNum;
	private String email;
	
	public Employee() {

	}

	public Employee(int ID, String name, int age, String department, String occupation, int salary, String phoneNum, String email) {
		this.setID(ID);
		this.setName(name);
		this.setAge(age);
		this.setOccupation(occupation);
		this.setDepartment(department);
		this.setSalary(salary);
		this.setPhoneNum(phoneNum);
		this.setEmail(email);
	}

	public String getName() {
		return name;
	}
	
	public String getOccupation() {
		return occupation;
	}
	
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String getDept() {
		return department;
	}

	public void setDepartment(String dept) {
		this.department = dept;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		if(phoneNum == null) {
			this.phoneNum = null;
		} else {
			this.phoneNum = "(" + phoneNum.substring(0,3) + ") " + phoneNum.substring(3,6) + "-" + phoneNum.substring(6);
		}
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	public void setID(int ID) {
		if(this.ID == -1)
			this.ID = ID;
	}

	public int getID() {
		return ID;
	}
	
	public String toString() {
		return "Employee: [ID: " + ID + ", Name: " + name + ", Age: " + age + ", Department: " + department + ", Salary: " + salary
				+ ", Phone Number: " + phoneNum + ", Email: " + email + "]";
	}

	public String toFileFormat() {
		return "" + ID + ",Employee," + name + "," + age + "," + department + "," + salary + "," + phoneNum + "," + email;
	}
	
}
