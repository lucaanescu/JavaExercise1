package com.cognixia.jump.First.project;

public class SetIdException extends Exception {
	
	/*
	 * This class creates an exception where the ID of an employee has already been set.
	 */

	private static final long serialVersionUID = -5361056761252556266L;
	
	public SetIdException() {
		super("The employee already has a set ID! This method can only be called upon employee creation.");
	}

}
