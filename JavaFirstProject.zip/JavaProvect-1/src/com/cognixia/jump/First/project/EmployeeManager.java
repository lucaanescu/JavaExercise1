package com.cognixia.jump.First.project;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.cognixia.jump.First.project.FullTimeEmployee;
import com.cognixia.jump.First.project.Employee;
import com.cognixia.jump.First.project.PartTimeEmployee;
import com.cognixia.jump.First.project.NoEmployee;

public class EmployeeManager {
	
	private static final int options = 7;
	
	public static void main(String[] args) throws IOException {

		File file = new File("EmployeeInfo.txt");
		String[] tempArray;
		if (!file.exists())
			file.createNewFile();

		FileReader fReader = new FileReader(file);
		BufferedReader reader = new BufferedReader(fReader);
		Scanner scan = new Scanner(System.in);

		ArrayList<String> fileLines = new ArrayList<String>();
		
		ArrayList<Employee> employeeSet = new ArrayList<Employee>();
		for (int i = 0; i < fileLines.size(); i++) {
			tempArray = fileLines.get(i).split(" ");
			if (tempArray.length > 4)
				employeeSet.add(new FullTimeEmployee(Integer.parseInt(tempArray[0]), tempArray[1], Integer.parseInt(tempArray[2]), tempArray[3].toUpperCase(), tempArray[4], Integer.parseInt(tempArray[5]),tempArray[6], tempArray[7]));
						
			else
				employeeSet.add(new Employee(Integer.parseInt(tempArray[0]), tempArray[1], Integer.parseInt(tempArray[2]), tempArray[3].toUpperCase(), tempArray[4], Integer.parseInt(tempArray[5]),tempArray[6], tempArray[7]));
		}
		
		boolean cond = true;
		System.out.println("What would you like to do in the Management System?");

		while (cond) {
			listOptions();
			int Option = getValidIntResponse(options, scan);

			switch (Option) {
			case 1:
				listEmployeeInfo(employeeSet, scan);
				break;
			case 2:
				listAllEmployeeNames(employeeSet, scan);
				break;
			case 3:
				addEmplyoee(employeeSet, scan);
				break;
			case 4:
				removeEmployee(employeeSet, scan);
				break;
			case 5:
				updateEmployee(employeeSet, scan);
				break;
			case 6:
				System.out.println("Thank you for using this Management System.");
				endOfProgram(employeeSet, file);
				cond = false;
				break;
			default:
				System.out.println("Can't do that.");
				break;
			}
		}
		scan.close();
	}

	private static int getValidIntResponse(int options, Scanner scan) {
		// TODO Auto-generated method stub
		return 0;
	}

	private static void endOfProgram(ArrayList<Employee> employeeSet, File file) throws IOException {
		FileWriter fReader = new FileWriter(file);
		BufferedWriter reader = new BufferedWriter(fReader);
		for (Employee e : employeeSet) {
			if (e instanceof FullTimeEmployee)
				reader.write(e.getID() + " " + e.getName() + " " + e.getAge() + " " + e.getDept() + " " + e.getOccupation() + " " + e.getSalary() + " " + e.getPhoneNum() + " " + e.getEmail() + " " + ((FullTimeEmployee) e) + "\n");
			else
				reader.write(e.getID() + " " + e.getName() + " " + e.getAge() + " " + e.getDept() + " " + e.getOccupation() + " " + e.getSalary() + " " + e.getPhoneNum() + " " + e.getEmail() + " " + "\n");
		}
		reader.close();
		
	}

	private static void updateEmployee(ArrayList<Employee> employeeSet, Scanner scan) {
		System.out.println("What is the ID of the Employee " + "that you would like to update?");
		int address = searchEmployeeID(employeeSet, scan);
		Employee dataTypes = employeeSet.get(address);
		Employee currentEmployee = employeeSet.get(address);
		boolean isCertain = false;
		if (currentEmployee instanceof FullTimeEmployee)
			isCertain = true;

		System.out.println("What do you need to update for " + employeeSet.get(address).getName() + "?");

		System.out.println("1: Change Name.");
		System.out.println("2: Change Occupation.");
		System.out.println("3: Change Department.");
		System.out.println("5: Change Email.");
		System.out.println("6: Change Salary.");
		
		int answer = getValidIntResponse(options, scan);

		switch (answer) {
		case 1:
			System.out.println("What would you like to change the Name to? \n Enter in \"FirstName LastName\" format with space between.");
			currentEmployee.setName(getStringValidated("Name", scan));
			break;
		case 2:
			System.out.println("What would you like to change  the Occupation to?"
					+ "(Current Occupation is: " + currentEmployee.getOccupation() + ")");
			currentEmployee.setOccupation(getStringValidated("Occupation", scan));
			break;
		case 3:
			System.out.println("What would you like to change the Department to? "
					+ "(Current Department is :" + currentEmployee.getDept() + ")");
			currentEmployee.setDepartment(getStringValidated("Department", scan));
			break;
		case 4:
			System.out.println("What would you like to change the Email to? "
					+ "(Current Email is :" + currentEmployee.getEmail() + ")");
			currentEmployee.setEmail(null);
			break;
		case 5:
			System.out.println("What would you like to change the Salary to? "
					+ "(Current Salary is :" + currentEmployee.getSalary() + ")");
			currentEmployee.setSalary(answer);
			break;
		default:
			System.out.println("This should not be reached.");
		}
		
	}


	private static String getStringValidated(String string, Scanner scan) {
		String holder = null;
		char acceptance;
		boolean cond = false;
		while (!cond) {
			scan.nextLine();
			holder = scan.nextLine();
			System.out.println(
					"You entered: " + holder + " for the new " + string + ". " + "\n Is this Acceptable?(Y/N)");
			acceptance = getYN(scan);
			if (acceptance == 'N') {
				System.out.println("What would you like to change " + string + " to?");
			} else
				cond = true;
		}
		return holder;
	}

	private static char getYN(Scanner scan) {
		boolean cond = false;
		char acceptance = 'l';
		while (!cond) {
			try {
				acceptance = scan.next().toUpperCase().charAt(0);
				if (acceptance != 'Y' && acceptance != 'N')
					throw new Exception();
				cond = true;

			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}
		return acceptance;
	}

	private static void removeEmployee(ArrayList<Employee> employeeSet, Scanner scan) {
		System.out.println("Remove by ID:");

		int address = searchEmployeeID(employeeSet, scan);
		Employee holder = employeeSet.remove(address);
		System.out.println("Employee: " + holder.getID() + ", " + holder.getName() + " has been removed!");
		
	}

	private static void addEmplyoee(ArrayList<Employee> employeeSet, Scanner scan) {
		System.out.println("Enter ID:");
		Integer ID = getUniqueID(employeeSet, scan);
		System.out.println("Enter Name:");
		String name = getStringValidated("Name", scan);
		System.out.println("Enter age:");
		Integer age = getIntegerValidated("age", scan);
		System.out.println("Enter Occupation:");
		String occupation = getStringValidated("Occupation", scan);
		System.out.println("Enter Department:");
		String department = getStringValidated("Department", scan);
		System.out.println("Enter Salary:");
		Integer salary = getIntegerValidated("Salary", scan);
		System.out.println("Enter Department:");
		String phoneNum = getStringValidated("PhoneNumber", scan);
		System.out.println("Enter Email:");
		String email = getStringValidated("Email", scan);
		System.out.println("Is this Employee Certified?");
		char acceptance = getYN(scan);
		if (acceptance == 'Y') {
			FullTimeEmployee addEmployee = new FullTimeEmployee(ID, name, age, occupation, department, salary, phoneNum, email);
			employeeSet.add(addEmployee);
		} else {
			Employee addEmployee = new Employee();
			employeeSet.add(addEmployee);
		}
		
	}

	private static Integer getIntegerValidated(String string, Scanner scan) {
		// TODO Auto-generated method stub
		return null;
	}

	private static int getUniqueID(ArrayList<Employee> employeeSet, Scanner scan) {
		int id = 0;
		boolean condition = false;
		while (!condition) {
			try {
				System.out.println("Enter ID: ");
				id = scan.nextInt();

				condition = true;
			} catch (InputMismatchException e) {
				System.out.println("Please Enter a number");
			}
		}
		return id;
	}

	private static void listAllEmployeeNames(ArrayList<Employee> employeeSet, Scanner scan) {
		System.out.println("Employees working here:");
		for (Employee e : employeeSet)
			System.out.println(e.getName());
	}

	private static void listEmployeeInfo(ArrayList<Employee> employeeSet, Scanner scan) {
		System.out.println("Which Employee are you looking to see information on?(Employee ID)");
		int address = searchEmployeeID(employeeSet, scan);
		Employee e = employeeSet.get(address);
		System.out.println("Employee: " + e.getID() + "\nName: " + e.getName() + "\nOccupation: "
				+ e.getOccupation() + "\nDepartment: ");
	}

	private static int searchEmployeeID(ArrayList<Employee> employeeSet, Scanner scan) {
		int D = -1;
		boolean condition = false;
		while (!condition) 
		{
			try {
				for (int i = 0; i < employeeSet.size(); i++) 
					{
						D = i;
						i = employeeSet.size() + 1;
						condition = true;
					}
				if (D == -1)
					throw new NoEmployee();

				} 
			catch (NoEmployee Employee) 
				{
					System.out.println("Please enter in a valid ID");
				}
		}
		return D;
	}
		

	private static void listOptions() {
		//lists what is possible in the program
		System.out.println("Your options are:");
		System.out.println("1: View Employee Information");
		System.out.println("2: View full list of Employee Names");
		System.out.println("3: Add an Employee to the list");
		System.out.println("4: Remove an Employee from the list");
		System.out.println("5: Update an Employee's information from the list");
		System.out.println("6: Exit Management Software.");
		
	}

}
