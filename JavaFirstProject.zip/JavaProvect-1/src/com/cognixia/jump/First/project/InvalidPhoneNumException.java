package com.cognixia.jump.First.project;

public class InvalidPhoneNumException extends Exception {
	
	/*
	 * This class creates an exception where the user inputs an invalid US phone number.
	 */

	private static final long serialVersionUID = -7578273273585559787L;
	
	public InvalidPhoneNumException() {
		super("The phone number entered is not a 10 digit phone number.");
	}

}
